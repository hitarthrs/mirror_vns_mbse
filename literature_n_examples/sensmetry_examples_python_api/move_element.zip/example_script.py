import pathlib
import syside

EXAMPLE_DIR = pathlib.Path(__file__).parent
MODEL_FILE_PATH = EXAMPLE_DIR / "example_model.sysml"


def print_package_members(package: syside.Package, indent: int = 0) -> None:
    """Print all direct children of a package by name."""
    prefix = "  " * indent

    for member in package.children.elements:
        name = member.declared_name or "<unnamed>"
        print(f"{prefix}- {name} ({type(member).__name__})")


def main() -> None:
    (model, diagnostics) = syside.load_model([MODEL_FILE_PATH])
    assert not diagnostics.contains_errors(warnings_as_errors=True)

    with model.user_docs[0].lock() as doc:
        root = doc.root_node

        # Locate the two packages and the element to move.
        # next() with a generator expression is a common Python idiom for finding
        # the first element that matches a condition. It raises StopIteration if
        # no match is found, which is appropriate here since the model is known.
        sensor_system = next(
            e
            for e in root.children.elements
            if isinstance(e, syside.Package)
            and e.declared_name == "SensorSystem"
        )
        processing_pkg = next(
            e
            for e in sensor_system.children.elements
            if isinstance(e, syside.Package) and e.declared_name == "Processing"
        )
        sensing_pkg = next(
            e
            for e in sensor_system.children.elements
            if isinstance(e, syside.Package) and e.declared_name == "Sensing"
        )
        processor_part = next(
            e
            for e in sensing_pkg.children.elements
            if isinstance(e, syside.PartUsage)
            and e.declared_name == "processor"
        )

        print("Before move:")
        print("  Processing:")
        print_package_members(processing_pkg, indent=2)
        print("  Sensing:")
        print_package_members(sensing_pkg, indent=2)

        # Extract the element from its current parent without clearing its subtree,
        # then append it to the new parent.
        sensing_pkg.children.extract_element(processor_part)
        processing_pkg.children.append(syside.OwningMembership, processor_part)

        print("\nAfter move:")
        print("  Processing:")
        print_package_members(processing_pkg, indent=2)
        print("  Sensing:")
        print_package_members(sensing_pkg, indent=2)

        # Serialize the updated model to SysML text
        printer = syside.ModelPrinter.sysml()
        cfg = syside.PrinterConfig(line_width=80, tab_width=4)
        print("\nUpdated model:")
        print(syside.pprint(root, printer, cfg))


if __name__ == "__main__":
    main()
