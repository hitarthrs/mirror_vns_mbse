Move Element
============

This example demonstrates how to move an element from one parent to another in a SysML
v2 model using Syside Automator.

The model contains a sensor system with two packages: ``Processing`` and ``Sensing``. A
``processor`` part usage is initially placed in ``Sensing`` but logically belongs in
``Processing``. The script extracts it from ``Sensing`` and appends it to
``Processing``, then prints the model before and after the move.

.. code-block:: text

    SensorSystem
    ├── Processing
    │   ├── SignalProcessor
    │   │                  <─ ─ ┐
    │   └── DataLogger          ┆
    └── Sensing                 ┆
        ├── TemperatureSensor   ┆ Move here
        ├── PressureSensor      ┆
        └── processor       ─ ─ ┘

Concepts Used
-------------

- :syside:`extract_element <syside.OwnedChildrenNodes.extract_element>` removes an
  element from its current parent without clearing its subtree, returning it as an
  orphan. The element can then be inserted elsewhere in the model tree.

  .. warning::

      ``extract_element`` can only move elements within the same document. Attempting to
      insert an extracted element into a different document will fail.

- :syside:`children.append <syside.OwnedChildrenNodes.append>` inserts the orphaned
  element under a new parent using the specified relationship type.
- After modification, :syside:`syside.pprint <syside.pprint>` serializes the updated
  model back to SysML text.

.. warning::

    It is the caller's responsibility to ensure that an extracted element is not leaked
    (i.e., it must be inserted into a new parent before the lock is released).
