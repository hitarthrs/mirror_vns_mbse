Filter Evaluation :bdg-success:`v0.8.5`
=======================================

This example evaluates SysML v2 filter expressions against model elements using
:syside:`Compiler.evaluate_filter <syside.Compiler.evaluate_filter>`.

It demonstrates two filter styles: presence-based filters (``@Electrical``,
``@Mechanical``) and value-based filters that match on metadata attributes using an enum
(``PartSource``). Results are displayed as filtered tree views or flat lists depending
on the filter type.

This pattern is useful when generating filtered BOMs, producing domain-specific
component views, or exporting element subsets to external tools.

Example Model Structure
-----------------------

The model is a vehicle system where each component carries two kinds of metadata:

- ``@Electrical`` or ``@Mechanical`` for domain classification (presence-based)
- ``@Source`` with a ``kind`` attribute for procurement type (value-based)

.. code-block:: text

    vehicle
    ├── chassis (@Mechanical)
    │   ├── brakingSystem (@Mechanical)
    │   │   ├── brakeECU (@Electrical)
    │   │   └── ...
    │   ├── steeringSystem (@Mechanical)
    │   └── suspension (@Mechanical)
    └── body
        ├── lighting (@Electrical)
        ├── infotainment (@Electrical)
        └── seats (@Mechanical)

.. note::

    Metadata annotations are applied directly to each part rather than inherited from
    part definitions. In SysML v2, metadata operates at the structural (model) level,
    not the semantic (type) level. A ``filter @Electrical`` checks the annotations on
    the element itself, not on its type definition. Placing ``@Electrical`` on a ``part
    def`` would not make its usages match the filter.

Six filter expressions are defined in two groups:

.. code-block:: sysml

    // Presence-based: select by metadata tag
    package ElectricalComponents { filter @ Electrical; }
    package MechanicalComponents { filter @ Mechanical; }

    // Value-based: select by metadata attribute value
    package COTS {
        filter (as Source).kind == PartSource::COTS;
    }

Value-based filters use the ``(as Source).kind`` pattern to access metadata attributes.
The ``as`` operator selects the matching metadata type from the element's annotations
and ``.kind`` accesses the attribute on it. This is important when elements carry
multiple metadata annotations (e.g. both ``@Electrical`` and ``@Source``), as it ensures
the attribute is evaluated on the correct metadata type.

.. note::

    The `SysML v2 training example
    <https://github.com/Systems-Modeling/SysML-v2-Release/blob/master/sysml/src/training/40.%20Filtering/Filtering%20Example-1.sysml>`_
    use ``Safety::isMandatory`` to access metadata attributes in filters. This works
    when references are resolved in the filtered element's scope. To avoid ambiguity
    between member access and plain references, use the cast operator ``(as
    Safety).isMandatory`` instead to explicitly select which metadata type to evaluate.

Concepts Used
-------------

**SysML v2 filter concepts:**

.. list-table::
    :widths: 25 25 50
    :header-rows: 1

    - - Concept
      - Syntax
      - Description
    - - Metadata definitions
      - ``metadata def``
      - Define a metadata type that can be applied to elements
    - - Metadata annotations
      - ``@Metadata``
      - Annotate an element with metadata
    - - Metadata with attributes
      - ``@Metadata { attr = val; }``
      - Annotate with metadata containing attribute values
    - - Filter expressions
      - ``filter @ Metadata;``
      - Select elements by metadata presence
    - - Metadata cast
      - ``(as Metadata).attr``
      - Cast to metadata type to access attributes in filters
    - - Enumerations
      - ``enum def`` / ``enum``
      - Define enumeration types with named literal values

**Syside API:**

.. list-table::
    :widths: 40 60
    :header-rows: 1

    - - API
      - Purpose
    - - :syside:`Compiler.evaluate_filter() <syside.Compiler.evaluate_filter>`
      - Evaluates a filter expression on the metadata of a target element
    - - :syside:`Model.elements() <syside.BaseModel.elements>`
      - Iterates over semantic elements, optionally including subtypes
    - - :syside:`ElementFilterMembership <syside.ElementFilterMembership>`
      - AST node containing a filter condition and its owning package
    - - :syside:`Element.owned_elements <syside.Element.owned_elements>`
      - Accesses direct children of an element
    - - :syside:`Namespace.owned_members <syside.Namespace.owned_members>`
      - Accesses direct members of an namespace. Avoids recursing into relationships.
    - - :syside:`LazyIterator.collect() <syside.LazyIterator.collect>`
      - Materializes lazy iterator into a list

Extracting Filter Expressions
-----------------------------

Each ``filter`` declaration in the SysML model (e.g. inside ``package COTS``) is
represented by an :syside:`ElementFilterMembership <syside.ElementFilterMembership>`
node. The script groups these by their owning package, since a package can contain
multiple filter expressions (all of which must match):

.. code-block:: python

    def get_filter_expressions(
        model: syside.Model,
    ) -> dict[syside.Package, list[syside.Expression]]:
        filter_groups: dict[syside.Package, list[syside.Expression]] = {}

        for efm in model.elements(syside.ElementFilterMembership):
            package = efm.parent
            if not isinstance(package, syside.Package):
                continue

            assert efm.condition is not None

            if package not in filter_groups:
                filter_groups[package] = []

            filter_groups[package].append(efm.condition)

        return filter_groups

Evaluating Filters
------------------

Filters don't propagate through the hierarchy, so each part must be checked
individually. The script walks the vehicle's part tree recursively and calls
:syside:`Compiler.evaluate_filter <syside.Compiler.evaluate_filter>` on every
:syside:`PartUsage <syside.PartUsage>`. The call returns a boolean (does this element
match?) for spec-conforming filter expressions, and a compilation report:

.. code-block:: python

    compiler = syside.Compiler()
    result, compilation_report = compiler.evaluate_filter(
        target=element,
        filter=filter_expr,
        stdlib=STANDARD_LIBRARY,
    )

The ``stdlib`` parameter provides the standard library needed for expression evaluation,
obtained via :syside:`syside.Environment.get_default() <syside.Environment.get_default>`
which ensures that reflective metaclasses are found and usable in expression evaluation.

Displaying Results
------------------

Source filters produce a flat list of matching part names. Domain filters produce a
filtered tree that preserves hierarchy: just listing matching parts would lose the
structural context of where they sit in the vehicle. The tree keeps non-matching
ancestors (shown in parentheses, e.g. ``(body)``) so the nesting remains readable:

.. code-block:: python

    @dataclass
    class FilteredNode:
        name: str
        children: list["FilteredNode"]


    def build_filtered_tree(
        element: syside.Namespace,
        matched_elements: list[syside.Element],
    ) -> FilteredNode | None:
        self_matches = element in matched_elements
        children = []
        for child in element.owned_members.collect():
            if isinstance(child, syside.PartUsage):
                subtree = build_filtered_tree(child, matched_elements)
                if subtree is not None:
                    children.append(subtree)
        if self_matches or children:
            name = element.name or "<anonymous>"
            return FilteredNode(
                name=name if self_matches else "(" + name + ")",
                children=children,
            )
        return None
