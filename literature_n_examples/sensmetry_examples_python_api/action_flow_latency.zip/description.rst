.. _action-flow-latency:

Action Flow Latency Analysis :bdg-primary-line:`Labs`
=====================================================

.. admonition:: Experimental feature
    :class: caution

    This example uses experimental unit conversion functionality.
    Enable with ``experimental_quantities=True``.

This example computes the total end-to-end latency of a sequential action pipeline by
following the succession chain from ``start`` and summing the ``latency`` attribute on
each step. It uses the same ``DataPipeline`` model as :ref:`action-flow-connectivity`
and :ref:`action-flow-type-check`.

Each action definition in the model carries a ``attribute latency : DurationValue = N
[min]`` using SI units. The script evaluates these attributes using the Syside
expression compiler.

Concepts Used
-------------

.. list-table::
    :widths: 40 60
    :header-rows: 1

    - - API
      - Purpose
    - - :syside:`SuccessionAsUsage <syside.SuccessionAsUsage>`
      - Links adjacent steps in an action sequence
    - - :syside:`ConnectorAsUsage <syside.ConnectorAsUsage>`
      - Endpoints of a succession (``source_feature`` / ``target_features``)
    - - :syside:`Compiler.evaluate_feature() <syside.Compiler.evaluate_feature>`
      - Evaluates an attribute expression within a given scope, returning a numeric
        value
    - - :syside:`Definition.owned_attributes <syside.Definition.owned_attributes>`
      - Attributes defined directly on an action definition
