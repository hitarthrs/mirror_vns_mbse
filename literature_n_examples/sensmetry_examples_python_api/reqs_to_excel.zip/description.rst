Requirements to Excel Spreadsheet
=================================

This simple Python script uses Syside and Pandas to load the requirements from SysML v2
file ``requirements.sysml`` and store them into an Excel file ``requirements.xlsx``.

Additional Dependencies
-----------------------

This example additionally requires ``pandas`` and ``openpyxl`` Python packages that can
installed using ``pip``. If you are using a virtual environment, ensure that you install
the packages into the same ``.venv`` where Syside Automator is installed.

.. code-block:: shell

    pip install pandas openpyxl
