Requirements from Excel Spreadsheet
===================================

This simple Python script uses Syside and Pandas to load a list of requirements from an
Excel file ``requirements.xlsx`` and store them into a SysML v2 file
``requirements.sysml``.

Additional Dependencies
-----------------------

This example additionally requires ``pandas`` and ``openpyxl`` Python packages that can
installed using ``pip``. If you are using a virtual environment, ensure that you install
the packages into the same ``.venv`` where Syside Automator is installed.

.. code-block:: shell

    pip install pandas openpyxl

Concepts Used
-------------

- :syside:`syside.Document.create_st <syside.Document.create_st>` is a function for
  creating a SysML document. The caller needs to specify the URL of the created document
  (we use ``memory://`` to indicate that the file is completely in memory) and whether
  the file is ``sysml`` or ``kerml``.
- Syside supports multithreaded access to the model. Therefore, the documents must be
  locked using the :syside:`lock <syside.SharedMutex.lock>` method before accessing
  them.
- New elements can be created by adding them with :syside:`append
  <syside.ChildrenNodes.append>` to the containing namespace.
- Writing to :syside:`body <syside.Documentation.body>` field of the documentation
  element updates its text.
- Function :syside:`pprint(<...>) <syside.pprint>` pretty prints an element (a concept
  of abstract syntax) to textual notation.

Excel File Contents
-------------------

The Excel file ``requirements.xlsx`` has the following contents:

===== ==================================================================================
ID    REQUIREMENT
===== ==================================================================================
RQ-01 The fridge shall maintain an internal temperature between 1°C and 4°C (34°F and
      39°F) for food preservation.
RQ-02 The freezer compartment shall maintain a temperature of -18°C (0°F) or below for
      long-term storage of frozen items.
RQ-03 The fridge shall meet or exceed Energy Star efficiency standards, consuming no
      more than 400 kWh per year.
RQ-04 The fridge shall have an automatic defrosting system to prevent the buildup of
      frost inside the freezer.
RQ-05 The fridge doors shall have magnetic gaskets to ensure an airtight seal and
      prevent energy loss.
RQ-06 The operational noise of the fridge shall not exceed 40 dB(A) under normal
      conditions.
RQ-07 The fridge shall provide adjustable shelves to accommodate a variety of food sizes
      and configurations.
RQ-08 The fridge shall include a digital temperature control system with an accuracy of
      ±1°C.
RQ-09 The fridge shall feature a humidity-controlled drawer to extend the freshness of
      perishable items like fruits and vegetables.
RQ-10 The fridge shall be equipped with energy-efficient LED lighting that illuminates
      all compartments.
RQ-11 The fridge shall have a built-in water and ice dispenser capable of dispensing
      both cubed and crushed ice.
RQ-12 The fridge shall support Wi-Fi connectivity, enabling remote temperature
      monitoring and control via a mobile app.
RQ-13 The fridge shall include an audible alarm system to notify users if the door is
      left open for more than 2 minutes.
RQ-14 The fridge shall provide a minimum storage capacity of 20 cubic feet, including
      separate compartments for dairy, meat, and produce.
RQ-15 The fridge shall include a backup battery or auxiliary power system capable of
      maintaining critical temperatures for at least 4 hours during a power outage.
===== ==================================================================================
