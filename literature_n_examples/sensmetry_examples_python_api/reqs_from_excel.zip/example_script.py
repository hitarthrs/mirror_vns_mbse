import pathlib
import pandas as pd
import syside

EXAMPLE_DIR = pathlib.Path(__file__).parent
REQUIREMENTS_EXCEL = EXAMPLE_DIR / "requirements.xlsx"
REQUIREMENTS_SYSML = EXAMPLE_DIR / "requirements.sysml"


def main() -> None:
    # Load requirements from Excel using Pandas.
    df = pd.read_excel(REQUIREMENTS_EXCEL)

    # Create a SysMLv2 document in memory.
    model_document = syside.Document.create_st(
        syside.DocumentOptions(
            url=syside.Url("memory://requirements.sysml"), language="sysml"
        )
    )

    # Since Syside is a multi-threaded application, we need to lock the
    # document to ensure that the document is not modified from another
    # thread while we are accessing or modifying it.
    with model_document.lock() as model:
        # The document corresponds to a single root namespace.
        root_namespace = model.root_node

        # Add an owned requirements package to the root namespace.
        requirements_package = root_namespace.children.append(
            syside.OwningMembership, syside.Package
        )[1]
        requirements_package.declared_name = "Requirements"

        # Create a SysML requirement for each row in Excel.
        for _, row in df.iterrows():
            req_id = row["ID"]
            req_doc = row["REQUIREMENT"]
            print(f"Creating requirement {req_id}: {req_doc}")

            requirement = requirements_package.children.append(
                syside.OwningMembership, syside.RequirementDefinition
            )[1]
            requirement.declared_name = req_id
            documentation = requirement.children.append(
                syside.OwningMembership, syside.Documentation
            )[1]
            documentation.body = req_doc

        # Pretty print abstract syntax to textual notation.
        printer_cfg = syside.PrinterConfig(line_width=80, tab_width=2)
        printer = syside.ModelPrinter.sysml()
        sysml_text = syside.pprint(root_namespace, printer, printer_cfg)

    print(f"Created SysML model:\n{sysml_text}")

    # Write textual notation to a file.
    with open("requirements.sysml", "w", encoding="utf-8") as fp:
        fp.write(sysml_text)


if __name__ == "__main__":
    main()
