Calc Evaluation :bdg-success:`v0.8.5` :bdg-primary-line:`Labs`
==============================================================

.. admonition:: Experimental feature
    :class: caution

    This example uses experimental unit conversion functionality.
    Enable with ``experimental_quantities=True``.

This example evaluates user-defined ``calc def`` expressions using
:syside:`Compiler.evaluate_feature <syside.Compiler.evaluate_feature>`. It demonstrates
chained calculations where each result feeds into the next, two ``calc def`` styles
(result expression vs return parameter), and automatic unit conversion across mixed
units.

The model computes geometry and physical properties of a steel beam from basic
dimensions, density, and gravity.

Example Model Structure
-----------------------

The model defines five calculation definitions that form a computation chain.
``SteelBeam`` uses composition to reference a ``CarbonSteel`` material and accesses its
``density`` via ``material.density``. Mixed units (``cm`` and ``m``) are automatically
converted during evaluation:

.. code-block:: text

    SteelBeam
    ├── material : CarbonSteel
    │   └── density = 7850 [kg⋅m⁻³]
    ├── width = 10 [cm]
    ├── height = 5 [cm]
    ├── depth = 2 [m]
    ├── topArea = AreaCalc(width, height)
    ├── surfaceArea = SurfaceAreaCalc(width, height, depth)
    ├── volume = VolumeCalc(topArea, depth)
    ├── density = material.density
    ├── mass = MassCalc(volume, density)
    └── weight = WeightCalc(mass, gravity)

Material is modeled using composition (``attribute material : CarbonSteel``) rather than
inheritance, since a beam is not a material but has one. ``Material`` and
``CarbonSteel`` are defined as ``attribute def`` types:

.. code-block:: sysml

    abstract attribute def Material {
        attribute density : DensityValue;
    }

    attribute def CarbonSteel :> Material {
        attribute :>> density = 7850 ['kg⋅m⁻³'];
    }

Two ``calc def`` styles are shown. Style 1 uses a result expression (the last expression
without a trailing semicolon):

.. code-block:: sysml

    calc def AreaCalc {
        in a : LengthValue;
        in b : LengthValue;
        a * b
    }

Style 2 uses an explicit ``return`` parameter. This style also demonstrates a calc
calling another calc internally:

.. code-block:: sysml

    calc def SurfaceAreaCalc {
        in width : LengthValue;
        in height : LengthValue;
        in depth : LengthValue;
        return attribute result : AreaValue =
            2.0 * (AreaCalc(width, height) + AreaCalc(width, depth) + AreaCalc(height, depth));
    }

Both styles are evaluated identically from the API perspective.

Concepts Used
-------------

**SysML v2 calc concepts:**

.. list-table::
    :widths: 25 25 50
    :header-rows: 1

    - - Concept
      - Syntax
      - Description
    - - Calc definitions
      - ``calc def``
      - Define reusable calculation functions with typed parameters
    - - Calc invocation
      - ``MassCalc(volume, density)``
      - Call a calc with arguments; results of one calc can feed into another
    - - SI quantity types
      - ``LengthValue``, ``MassValue``
      - Typed attributes with physical units from the SI library
    - - Attribute definitions
      - ``attribute def``
      - Define reusable attribute types with default values
    - - Attribute redefinition
      - ``attribute :>> density``
      - Override an inherited attribute value
    - - Abstract attributes
      - ``abstract attribute <g> gravity``
      - Package-level constants reusable across parts

**Syside API:**

.. list-table::
    :widths: 40 60
    :header-rows: 1

    - - API
      - Purpose
    - - :syside:`Compiler.evaluate_feature() <syside.Compiler.evaluate_feature>`
      - Evaluates a feature (attribute, calc usage) within a given scope
    - - :syside:`Model.elements() <syside.BaseModel.elements>`
      - Iterates over semantic elements, optionally including subtypes
    - - :syside:`Usage.usages <syside.Usage.usages>`
      - Accesses features (attributes, parts) of a usage or definition
    - - :syside:`Document.document_tier <syside.BasicDocument.document_tier>`
      - Returns the document tier (StandardLibrary, External, or Project)
    - - :syside:`LazyIterator.collect() <syside.LazyIterator.collect>`
      - Materializes lazy iterator into a list

Evaluating Calc Definitions
---------------------------

The script finds the ``SteelBeam`` part definition and collects its project-level
attributes. Each attribute is evaluated using :syside:`Compiler.evaluate_feature
<syside.Compiler.evaluate_feature>` with the part definition as scope:

.. code-block:: python

    def evaluate_feature(
        feature: syside.Feature, scope: syside.Type
    ) -> syside.Value | None:
        compiler = syside.Compiler()
        value, compilation_report = compiler.evaluate_feature(
            feature=feature,
            scope=scope,
            stdlib=STANDARD_LIBRARY,
            experimental_quantities=True,
        )
        return value

The ``experimental_quantities=True`` flag enables automatic unit conversion. When
``width = 10 [cm]`` and ``depth = 2 [m]`` are multiplied, the compiler converts both to
SI base units before computing the result.

Chained calculations work because ``evaluate_feature`` resolves attribute references
transitively. When evaluating ``weight``, the compiler follows the chain:
``WeightCalc(mass, gravity)`` → ``MassCalc(volume, density)`` → ``VolumeCalc(topArea,
depth)`` → ``AreaCalc(width, height)``, evaluating each calc definition along the way.
