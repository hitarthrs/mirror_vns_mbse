Extract Documentation
=====================

This simple Python script uses Syside to extract information from all the `doc` elements
present in the model and print it out in the console.

The example covers unordered iteration over elements of specific type.

Concepts Used
-------------

- :syside:`syside.load_model <syside.load_model>` is the main function for loading the
  model. In the example, the parameter `paths` is used to specify the path to the
  SysMLv2 file. This parameter accepts a list of paths. :syside:`load_model
  <syside.load_model>` also accepts parameters `sysml_source` and `kerml_source` that
  can be used to load SysMLv2 and KerML files from memory, respectively.
- :syside:`.nodes <syside.Model.nodes>` method on :syside:`model <syside.Model>` enables
  iterating over the elements of the given type. By default, it returns only the
  instances that match the type exactly. The behaviour can be changed to include
  subtypes by setting the parameter `include_subtypes` to `True`.
- :syside:`.name <syside.Element.name>` on :syside:`element <syside.Element>` enables
  accessing the name of SysML element.
- :syside:`.body <syside.Documentation.body>` on :syside:`documentation
  <syside.Documentation>` enables accessing the annotation text for the comment.

Interactive version
-------------------

Save the example model below to your computer and run `python3 -m syside interactive
path/to/downloaded/example_model.sysml` with the Syside venv activated. This drops you
into an interactive Python shell that starts with a banner:

.. code-block:: shell

    Welcome to isyside!

    This is an interactive Python shell with the loaded model accessible as `model`.
    Builtin modules:        syside
    Convenience variables:  model, diagnostics

    >>>

From here, you can access the model described in `example_model.sysml` as `model`. For
example

.. code-block:: python

    model.nodes(syside.Documentation)

gives an iterator over all documentation elements in the model. We can use this to
create a list of all documentation elements

.. code-block:: python

    >>> doc_elements = list(model.nodes(syside.Documentation))
    >>>

These elements might have names of their own

.. code-block:: python

    >>> doc_elements[2].name
    'Document1'
    >>>

or may be anonymous

.. code-block:: python

    >>> doc_elements[1].name
    >>>

and will typically have a body

.. code-block:: python

    >>> doc_elements[0].body
    'This is documentation of the owning\npackage.'
    >>> doc_elements[1].body
    'This is documentation of Automobile alias.'
    >>> doc_elements[2].body
    'This is documentation of Automobile.'
    >>>

The text in the body concerns the element that _owns_ the documentation element. This
_owning_ element can be accessed through `owner`

.. code-block:: python

    >>> doc_elements[2].owner.name
    'Automobile'
    >>>

If a fully qualified name is needed, use `qualified_name`:

.. code-block:: python

    >>> qn = doc_elements[2].owner.qualified_name
    >>> qn
    syside.core.QualifiedName(['Documentation Example', 'Automobile'])
    >>> str(qn)
    "'Documentation Example'::Automobile"
    >>>
