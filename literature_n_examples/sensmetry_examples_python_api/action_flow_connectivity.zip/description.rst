.. _action-flow-connectivity:

Action Flow Port Connectivity
=============================

This example checks whether every port (``in item`` / ``out item``) on each sub-action
inside an action definition is covered by at least one item flow. Unconnected ports are
reported so that incomplete wiring can be caught early.

This example uses the same ``DataPipeline`` model as :ref:`action-flow-type-check` and
:ref:`action-flow-latency`. In this model, the ``Publish`` action has an ``in item tag :
Tag`` port that is intentionally left without a flow.

Concepts Used
-------------

.. list-table::
    :widths: 40 60
    :header-rows: 1

    - - API
      - Purpose
    - - :syside:`FlowUsage <syside.FlowUsage>`
      - Port endpoints of an item flow (``source_output_feature`` /
        ``target_input_feature``)
    - - :syside:`ConnectorAsUsage <syside.ConnectorAsUsage>`
      - Owning action usages at each end of the flow (``source_feature`` /
        ``target_features``)
    - - :syside:`Type.inputs <syside.Type.inputs>` / :syside:`Type.outputs
        <syside.Type.outputs>`
      - Item ports declared on an action usage
    - - :syside:`FeatureDirectionKind <syside.FeatureDirectionKind>`
      - Direction of a port feature (``In``, ``Out``, ``Inout``)
