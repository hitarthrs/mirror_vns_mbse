import pathlib
import syside

EXAMPLE_DIR = pathlib.Path(__file__).parent
MODEL_FILE_PATH = EXAMPLE_DIR / "example_model.sysml"

type ConnectedPort = tuple[str, str]


def check_port_connectivity(model: syside.Model, action_def_name: str) -> None:
    """Check whether every port on each sub-action inside a named action
    definition is covered by at least one item flow. Report any port that
    is not connected."""

    # Build a set of (action qualified name, port name) pairs that appear
    # as endpoints in at least one FlowUsage.
    connected: set[ConnectedPort] = set()

    for flow in model.nodes(syside.FlowUsage):
        owning_def = flow.owning_definition
        if owning_def is None or owning_def.name != action_def_name:
            continue

        # Record source port
        src_action = flow.source_feature
        src_port = flow.source_output_feature
        if (
            src_action is not None
            and src_port is not None
            and src_port.name is not None
        ):
            connected.add((str(src_action.qualified_name), src_port.name))

        # Record target port
        for tgt_action in flow.target_features.collect():
            tgt_port = flow.target_input_feature
            if tgt_port is not None and tgt_port.name is not None:
                connected.add((str(tgt_action.qualified_name), tgt_port.name))

    # Compare each sub-action's ports against the connected set.
    unconnected_found = False
    for action in model.nodes(syside.ActionUsage):
        owning_def = action.owning_definition
        if owning_def is None or owning_def.name != action_def_name:
            continue

        ports = {*action.inputs.collect(), *action.outputs.collect()}
        for port in ports:
            if port.name is None:
                continue
            action_qname = str(action.qualified_name)
            key: ConnectedPort = (action_qname, port.name)
            if key not in connected:
                direction = "in"
                if port.direction == syside.FeatureDirectionKind.Out:
                    direction = "out"
                elif port.direction == syside.FeatureDirectionKind.Inout:
                    direction = "inout"
                print(
                    f"  [UNCONNECTED] {action.name}.{port.name} ({direction})"
                )
                unconnected_found = True

    if not unconnected_found:
        print("  All ports are connected.")


def main() -> None:
    (model, diagnostics) = syside.load_model([MODEL_FILE_PATH])
    assert not diagnostics.contains_errors(warnings_as_errors=True)

    action_def = "Pipeline"
    print(f"Port connectivity report for {action_def}:")
    check_port_connectivity(model, action_def)


if __name__ == "__main__":
    main()
