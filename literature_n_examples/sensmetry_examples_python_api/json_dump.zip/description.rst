JSON Export :bdg-primary-line:`Labs`
====================================

This example illustrates exporting the root namespace loaded from a file to the SysML v2
JSON serialization format. The main function of interest is :syside:`syside.json.dumps
<syside.json.dumps>`, which takes an :syside:`Element <syside.Element>` and generates a
string representation of a SysML v2 JSON serialization. The serialization includes the
element and (recursively) all its owned members. Typically, as in this example, you
would serialize the root namespace of a loaded document.
