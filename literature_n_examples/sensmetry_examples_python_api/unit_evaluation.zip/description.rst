Value Rollup with Unit Conversion :bdg-primary-line:`Labs`
==========================================================

.. admonition:: Experimental feature
    :class: caution

    This example uses experimental unit conversion functionality.
    Enable with ``experimental_quantities=True``.

This example demonstrates recursive value aggregation with automatic unit conversion
using ``Compiler.evaluate_feature()``. It showcases two rollup scenarios:

1. **Mass Rollup** - Aggregating mass from vehicle components
2. **Power Rollup** - Calculating total power consumption for an aircraft

Both examples use the subsetting pattern where child components declare membership using
``subsets`` relationships, and the Python API builds explicit lists to enable expression
evaluation. It is worth noting that subsetting pattern could lead to multiple possible
values.

.. admonition:: Ambiguous subset definition example
    :class: note

    A vehicle electrical system has a main bus and an emergency bus (subset of main).
    Emergency loads (fuelPump 8A) subset `emergencyBus.loads`. Regular loads (headlights
    10A) subset `mainBus.loads`.

    When calculating mainBus.totalCurrent, there is ambiguity on how the emergency loads
    should be included. Since emergencyBus subsets mainBus, the answer could be: - 10A
    (only explicit mainBus loads) - 18A (mainBus loads + emergency loads, transitively)

    Both interpretations are valid. However, undersizing a battery based on 10A would lead to
    system failure.

    .. code-block:: sysml

        part vehicle {
            part mainBus : ElectricalBus;
            part emergencyBus : ElectricalBus subsets mainBus;

            part fuelPump : ElectricalLoad subsets emergencyBus.loads { current = 8A }
            part headlights : ElectricalLoad subsets mainBus.loads { current = 10A }

            // mainBus.totalCurrent = 10A or 18A?
            // Need explicit: mainBus.loads = (fuelPump, headlights)
        }

Mass Rollup Example
-------------------

The vehicle mass rollup calculates total mass by aggregating values from nested
components, each specifying mass in different units (kg, tonne, g):

.. code-block:: text

    vehicle
    ├── chassis (100 kg)
    │   ├── drivetrain (1 tonne)
    │   └── suspension (200 kg)
    └── engine (500000 g)

Power Rollup Example
--------------------

The aircraft power rollup calculates total power consumption from powered subsystems,
demonstrating selective aggregation where only powered components (those subsetting
``poweredSubsystems``) contribute to the total:

.. code-block:: text

    aircraft (20 W)
    ├── avionics (15 W)
    │   ├── navigationSystem (10 W)
    │   │   ├── gps (5 W)
    │   │   ├── imu (300 mW)
    │   │   ├── altimeter (100 mW)
    │   │   └── magnetometer (80 mW)
    │   ├── radar (120 W)
    │   └── autopilot (35 W)
    └── propulsion (1.2 kW)

Note that structural components like wings or fuselage would not contribute to power
consumption, as they don't subset ``poweredSubsystems``.

Building Explicit Subset Lists
------------------------------

The subsetting pattern (``part chassis subsets subcomponents``) requires explicit lists
for expression evaluation. The example includes a helper function that programmatically
builds these lists:

.. code-block:: python

    build_explicit_subset_list(
        element=root_element,
        part_def=rollup_type,
        subsetting_collection=subparts_collection,
    )

This converts implicit subsetting relationships into explicit comma-separated lists in
memory, enabling the rollup expressions to evaluate correctly.

.. note::

    Explicit subset lists are needed because SysML v2 specification defines subsetting
    as a relationship between collections, not a specification of which elements belong
    to each subset. Without explicit membership, value calculations cannot determine
    which elements to aggregate.

Evaluating with Unit Conversion
-------------------------------

The rollup expressions are evaluated using:

.. code-block:: python

    compiler = syside.Compiler()
    value, report = compiler.evaluate_feature(
        feature=rollup_attribute,  # Attribute to calculate
        scope=root_element,  # Evaluate in context of this part
        stdlib=model.environment.lib,  # Standard library for evaluation
        experimental_quantities=True,  # Enable automatic unit conversion
    )

The compiler converts all units to SI base units and returns scalar values:

- **Mass rollup**: ``1800.0`` (kg)
- **Power rollup**: ``1405.48`` (W)
