Extract Parts
=============

This simple Python script uses Syside to show:

- the ownership tree of all elements in the model
- part decomposition that are used in the model
- all parts that are typed by the ``Electrical`` part definition
- all parts that are typed by the ``Mechanical`` part definition

Concepts Used
-------------

- :syside:`syside.load_model <syside.load_model>` is the main function for loading the
  model. In the example, the parameter ``paths`` is used to specify the path to the
  SysMLv2 file. This parameter accepts a list of paths. :syside:`syside.load_model
  <syside.load_model>` also accepts parameters ``sysml_source`` and ``kerml_source``
  that can be used to load SysMLv2 and KerML files from memory, respectively.
- Syside supports multithreaded access to the model. Therefore, the documents must be
  locked using the :syside:`lock <syside.SharedMutex.lock>` method before accessing
  them.
- A :syside:`try_cast(<...>) <syside.AstNode.try_cast>` is used here to assert that
  extracted element is of desired type.
- A :syside:`Model <syside.Model>` is SysMLv2 model represented using abstract syntax.
  This is the output of the function :syside:`syside.load_model(<...>)
  <syside.load_model>`.
- A :syside:`root_node <syside.Document.root_node>` is an entry node in the tree. It can
  be considered as root :syside:`Namespace <syside.Namespace>`. The :syside:`Namespace
  <syside.Namespace>` is an :syside:`Element <syside.Element>` that contains other
  :syside:`Elements <syside.Element>`, that are known as :syside:`members
  <syside.Namespace.members>`.
