.. _action-flow-type-check:

Action Flow Type Compatibility
==============================

This example checks whether the item type flowing out of each source port is compatible
with the type expected by the destination port. A flow is compatible when the source
type is the same as, or a specialization of, the destination type.

This example uses the same ``DataPipeline`` model as :ref:`action-flow-connectivity` and
:ref:`action-flow-latency`. In this model, the flow from ``Analyze`` to ``Publish``
passes an ``AnalysisResult`` where a ``Report`` is expected — a type mismatch, since
``AnalysisResult`` does not specialize ``Report``.

Concepts Used
-------------

.. list-table::
    :widths: 40 60
    :header-rows: 1

    - - API
      - Purpose
    - - :syside:`FlowUsage <syside.FlowUsage>`
      - Port features at each end of a flow (``source_output_feature`` /
        ``target_input_feature``)
    - - :syside:`Feature.types <syside.Feature.types>`
      - Type chain for a feature; filter by ``DocumentTier.Project`` to isolate the
        user-defined type
    - - :syside:`Type.specializes() <syside.Type.specializes>`
      - Returns whether one type is the same as, or a specialization of, another
    - - :syside:`DocumentTier <syside.DocumentTier>`
      - Source tier of an element (``StandardLibrary``, ``External``, ``Project``)
