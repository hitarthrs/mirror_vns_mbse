JSON Import :bdg-primary-line:`Labs`
====================================

This example illustrated importing SysML v2 model from a JSON file by deserializing it.
The main function of interest is :syside:`syside.json.loads <syside.json.loads>`, which
takes a JSON array ``s`` and a ``document`` of class :syside:`Document
<syside.Document>` that the deserialized model will be stored in. The
:syside:`syside.json.loads <syside.json.loads>` function returns the deserialized model
which can then be used as if it was imported from a ``.sysml`` file.

Concepts Used
-------------

- A :syside:`Model <syside.Model>` is a SysMLv2 model represented using abstract syntax.
  This is the output of the function :syside:`syside.load_model <syside.load_model>`.
- The ``syside.json`` module for serializing to SysML v2 JSON.
- ``walk_ownership_tree`` is a function that prints out elements in a model in a
  tree-like format. In this example it is used to show that the model has been
  successfully deserialized from JSON format.
