Extract Variants
================

This example extracts and displays nested variant configurations from a SysML v2 model.
It shows how to find variation definitions, walk through part hierarchies with variant
subsets, evaluate attributes, and handle attribute redefinition.

Example Model Structure
-----------------------

The model demonstrates product line configuration using vehicle seat variants:

.. code-block:: text

    AvailableConfigurations
    ├── economy
    │   └── seat (basicSeat)
    │       ├── material = FauxLeather
    │       ├── heatingElement (singleZone)
    │       │   └── heatingPower = 45W
    │       └── adjustmentHandle
    ├── comfort
    │   └── seat (basicSeat)
    │       ├── material = FauxLeather
    │       ├── heatingElement (dualZone)
    │       │   └── heatingPower = 75W
    │       └── adjustmentHandle
    ├── premiumEco
    │   └── seat (premiumSeat)
    │       ├── material = RealLeather
    │       ├── heatingElement (singleZone)
    │       │   └── heatingPower = 45W
    │       └── adjustmentHandle
    └── luxury
        └── seat (premiumSeat)
            ├── material = RealLeather
            ├── heatingElement (dualZone)
            │   └── heatingPower = 75W
            └── adjustmentHandle

Each configuration combines seat types (``basicSeat`` vs ``premiumSeat``) with heating
systems (``singleZone`` vs ``dualZone``). This pattern is typical in product line
engineering where variations define multiple valid product configurations using
subsetting.

Concepts Used
-------------

**SysML v2 variation concepts:**

.. list-table::
    :widths: 25 25 50
    :header-rows: 1

    - - Concept
      - Syntax
      - Description
    - - Variation definitions
      - ``variation part def``
      - Define multiple variant alternatives
    - - Variant parts
      - ``variant part``
      - Specific alternatives within a variation
    - - Subsetting variants
      - ``seat subsets basicSeat``
      - Select which variant to use via subsetting
    - - Attribute redefinition
      - ``attribute :>> material``
      - Override inherited attribute values

**Syside API:**

.. list-table::
    :widths: 40 60
    :header-rows: 1

    - - API
      - Purpose
    - - :syside:`Model.elements() <syside.BaseModel.elements>`
      - Finds elements of a specific type
    - - :syside:`Compiler.evaluate_feature() <syside.Compiler.evaluate_feature>`
      - Evaluates attribute values within a scope
    - - :syside:`Usage.usages <syside.Usage.usages>`
      - Accesses ``features`` (parts and attributes, owned or inherited) of the
        ``Usage`` element
    - - :syside:`PartDefinition.variants <syside.Definition.variants>`
      - Accesses variant configurations
    - - :syside:`Document.document_tier <syside.BasicDocument.document_tier>`
      - Returns the document tier of an element (StandardLibrary, External, or Project)
    - - :syside:`Redefinition <syside.Redefinition>`
      - Relationship indicating attribute redefinition
    - - :syside:`LazyIterator.collect() <syside.LazyIterator.collect>`
      - Materializes lazy iterator into a list

Walking Part Hierarchies
------------------------

The script recursively walks through the part ownership tree to display the complete
configuration structure:

.. code-block:: python

    def walk_ownership_tree(element: syside.PartUsage, level: int = 0) -> None:
        # Print part name
        if element.name is not None:
            print("  " * level, f"Part: {element.name}")

        # Show attributes and their evaluated values
        show_part_attributes(element, level)

        # Recursively process child parts
        filtered_children = [
            x
            for x in element.usages.collect()
            if type(x) is syside.PartUsage
            and x.document.document_tier is syside.DocumentTier.Project
        ]
        for child in filtered_children:
            walk_ownership_tree(child, level + 1)

This walks the part hierarchy, evaluating attributes at each level and recursively
processing nested parts.

Evaluating Attributes
---------------------

The script uses the compiler to evaluate attribute values within their scope:

.. code-block:: python

    def evaluate_feature(
        feature: syside.Feature, scope: syside.Type
    ) -> syside.Value | None:
        compiler = syside.Compiler()
        value, compilation_report = compiler.evaluate_feature(
            feature=feature,
            scope=scope,
            stdlib=STANDARD_LIBRARY,
            experimental_quantities=True,
        )
        return value

This evaluates redefined attributes like ``attribute :>> material =
Materials::FauxLeather`` to get their actual values in the context of each variant
configuration.

Handling Attribute Redefinition
-------------------------------

When attributes are redefined in variant configurations, the script deduplicates them to
show only the active (most-derived) version:

.. code-block:: python

    def deduplicate_attributes(
        attributes: list[syside.AttributeUsage],
    ) -> list[syside.Feature]:
        redefined = set()
        for attribute in attributes:
            for inherited_relationship in attribute.heritage.relationships:
                if isinstance(inherited_relationship, syside.Redefinition):
                    redefined.add(inherited_relationship.first_target)
        return [attr for attr in attributes if attr not in redefined]

This prevents displaying both the base and redefined versions of the same attribute,
showing only the final effective value.

Filtering Members
-----------------

The script filters members to show only relevant model elements:

.. code-block:: python

    # Get only user-defined attributes (exclude standard library)
    filtered_attributes = deduplicate_attributes(
        [
            x
            for x in part.usages.collect()
            if type(x) is syside.AttributeUsage
            and x.document.document_tier is syside.DocumentTier.Project
        ]
    )

    # Get only child parts (exclude library elements)
    filtered_children = [
        x
        for x in element.usages.collect()
        if type(x) is syside.PartUsage
        and x.document.document_tier is syside.DocumentTier.Project
    ]

The ``.collect()`` method materializes the lazy iterator into a list. The filtering uses
``document.document_tier`` to show only project-level elements (excluding standard
library and external dependencies). For attributes, deduplication ensures only the
most-derived (redefined) versions are shown.

.. tip::

    **Document Tiers** categorize elements by their source:

    - ``StandardLibrary`` - Built-in standard library elements that rarely change
    - ``External`` - Third-party library elements that change only with library updates
    - ``Project`` - User-defined project elements that may be edited at any time

    Filtering by ``DocumentTier.Project`` ensures you see only the elements you have
    defined, excluding standard library and imported elements.
