Syside Class Names
==================

This example shows how you can use :syside:`syside.sexp <syside.sexp>` function to print
the symbolic expression of the document to see what elements it contains and, most
importantly, names of the Syside Python classes.
