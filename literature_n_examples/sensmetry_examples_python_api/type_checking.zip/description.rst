Type Checking
=============

This simple Python script shows off Syside's type checking capabilities. In the provided
example model, there are six packages:

- ``Non-Conforming Types 1``
- ``Non-Conforming Types 2``
- ``Conforming Types 1``
- ``Collect``
- ``Select``
- ``Arrays``

In the first package, the ``a`` attribute is a ``Boolean`` and the ``b`` attribute is
defined to be a ``String``. However, we are assigning ``a`` to ``b``, which is not
allowed because ``Boolean`` does not conform to ``String``.

In the second package, the ``b`` attribute is defined to be a ``Positive``. However, we
are assigning a value of ``-42`` to it, which is inferred to be an ``Integer`` and thus
is not conformant to ``Positive``. The ``a`` attribute is defined and assigned
correctly.

The third package is allowed because both attributes are ``Positive`` and conform to the
``ScalarValues::Positive`` type.

The fourth package ``Collect`` shows type inference working on standard ``collect``
function. In both cases, the feature values are inferred to return types ``A``, thus
only attribute ``b`` is diagnosed with an invalid type.

Similarly to the previous package, ``Select`` shows type inference correctly identifying
that the expression of ``a`` selects only ``Positive`` values, and thus it is not an
error to assign the result to ``a``. Expression of ``b`` does no such checking,
therefore it if inferred to return ``Integer`` values from the negative range lower
bound which is diagnosed as a type error when being assigned to ``Positive``.

The last package ``Arrays`` shows inference working on owned argument features, and
collection and array indexing correctly inferring the return type to be
``Arrays::array::elements`` which conforms to ``Positive``, hence no type errors. Note
that because ``operator #`` is statically ambiguous, this inference only works by
explicitly calling ``CollectionFunctions::'#'`` and ``CollectionFunctions::'array#'``
functions. The ambiguity stems from the operator handling single ordered collections and
arrays differently to all other sequences, of which the multiplicity cannot be
statically known in all cases since everything is both a sequence and a single value at
the same time in SysML v2.

Most other standard library functions that are definitions of operator functions, or
operate on sequences, are also treated as special functions by the type inference to
reduce the boilerplate needed to satisfy the type checker.

Concepts Used
-------------

This example only uses the ``load_model`` function.
